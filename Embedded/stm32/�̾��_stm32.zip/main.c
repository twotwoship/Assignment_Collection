#include "device_driver.h"
#include <stdio.h>
#define BASE (500) // msec

#define BUTTON_STABLE_COUNT 100 // 100번 같아야 한다

#define TIM4_TICK (20)					// usec
#define TIM4_FREQ (1000000 / TIM4_TICK) // Hz
#define TIME4_PLS_OF_1ms (1000 / TIM4_TICK)
#define TIM4_MAX (0xffffu)

static void Sys_Init(int baud)
{
	SCB->CPACR |= (0x3 << 10 * 2) | (0x3 << 11 * 2);
	Clock_Init();
	Uart2_Init(baud);
	setvbuf(stdout, NULL, _IONBF, 0);
	LED_Init();
}

volatile int button_raw_prev = 0;	// 버튼 이전 원본 값
volatile int button_same_count = 0; // 버튼이 계속 같은 값인지 체크
volatile int button_stable = 0;		// 최종 버튼 확정 상태 0으로 확정이냐 1으로 확정시키냐
volatile int button_raw = 0;		// 내가 의도한 버튼 값

volatile int handle_lock = 0;		  // 내가 만든놈
volatile int handle_lock_check = 0;	  // 타이머2 플래그 체크 시올라옴
volatile int long_press_detected = 0; // 이 친구가 버튼을 3초이상 누르고 뗏을때 바로 다시 돌아가지 않게 만들어줌
volatile int Button_lock = 0;		  // 버튼 눌리면 세워짐
volatile int Sys_Time = 0;			  // 1ms 마다 1씩 올라감
volatile int button_pressed = 0;	  // 버튼이 눌리면 1로 변경

volatile int Key_Pressed = 0;
volatile int Uart_Data_In = 0;		  // uart 인터럽트 발생시 1 끝나면 0
volatile unsigned char Uart_Data = 0; // uart 인터럽트 수신한 데이타저장장소

volatile int TIM4_Expired = 0; // 타이머 4 인터럽트
volatile int insite_check = 0;

volatile int pwm_motor_value = 500; // 50%에서 시작
volatile int uart_pwm_mode = 0;		// 0: 버튼 GPIO, 1: UART PWM

typedef enum
{
	BUTTON_NONE = 0,
	BUTTON_SHORT,
	BUTTON_LONG,
} button_event_t; // 버튼 상태

typedef enum
{
	stop = 0,
	CW,
	CCW,
} motor_state_t; // 모타 상태

button_event_t button_event;
motor_state_t motor_state;
/*
과거의 유산
void TIM2_init_self(void);				// 타이머 2 키기 및 초기화
void TIM2_start_self(void);				// 타이머 2 시작
void TIM2_stop_self(void);				// 타이머 2 멈춰잇
*/

void TIM5_init_self(void);			 // 타이머 5 켜기 및 초기화
void TIM5_start_self(void);			 // 타이머 5 시작
void TIM5_stop_self(void);			 // 타이머 5 멈춰잇
void Motor_Handle(void);			 // 모터 이벤트 처리
void Motor_CW(void);				 // 모터 정방향 명령
void Motor_CCW(void);				 // 모터 역방향 명령
void Motor_Stop(void);				 // 모터 값 변경
void uart_Motor_CW(void);			 // 모터 정방향 명령
void uart_Motor_CCW(void);			 // 모터 역방향 명령
void uart_Motor_Stop(void);			 // 모터 값 변경
void Motor_Wait(void);				 // 모터 정지 명령
void Button_Event_Handle(void);		 // 버튼 이벤트 처리
void button_motor_init_myself(void); // 버튼 모터 초기화
void motor_pwm_timer_init_self(void);
void uart_motor_handle(void);

// uart 핸들먼저 만들자
// 내가 입력한게 uart로 들어가야되니까 수신을 만들어야함

void button_motor_init_myself(void)
{ // 버튼 모터 다 초기화해
	Macro_Set_Bit(RCC->AHB1ENR, 2);
	Macro_Write_Block(GPIOC->MODER, 0x3, 0x0, 26);

	Macro_Set_Bit(RCC->AHB1ENR, 0); // gpioa on

	Macro_Clear_Area(GPIOA->MODER, 0x3, 0);
	Macro_Clear_Area(GPIOA->MODER, 0x3, 2);

	Macro_Write_Block(GPIOA->MODER, 0x3, 0x01, 0); // PA0 output
	Macro_Write_Block(GPIOA->MODER, 0x3, 0x01, 2); // PA1 output
	Macro_Write_Block(GPIOA->MODER, 0x3, 0x00, 8); // PA4 input

	Macro_Write_Block(GPIOA->PUPDR, 0x03, 0x01, 8); // pa4 inside_pull-up
}

//
#define TIM2_FREQ (100000) // Hz

void motor_pwm_timer_init_self(void)
{									// 타이머 2로 제어하는 모터 PWM
	Macro_Set_Bit(RCC->AHB1ENR, 0); // gpioa on

	Macro_Write_Block(GPIOA->MODER, 0x3, 0x2, 0);  	// PB0 => ALT
	Macro_Write_Block(GPIOA->AFR[0], 0xF, 0x01, 20); // PA5 alternate function af01 tim2 ch1
	Macro_Write_Block(GPIOA->AFR[0], 0xF, 0x01, 4); // PA1 alternate function af01 tim2 ch2

	Macro_Set_Bit(RCC->APB1ENR, 0); // timer 2 on
	Macro_Clear_Bit(TIM2->CR1, 7);
	TIM2->CR1 = (1 << 4 | 0 << 3);
	TIM2->PSC = (int)(TIMXCLK / TIM2_FREQ) - 1;
	TIM2->ARR = 1000 - 1; // 해상도 천짜리임
	TIM2->EGR = (1 << 0);
	TIM2->CCMR1 = 0;
	TIM2->CCMR1 = ((1 << 6) | (1 << 5) | (1 << 3) ); // 채널 1번 110으로 세팅
	Macro_Set_Bit(TIM2->CCER, 0);
	Macro_Clear_Bit(TIM2->CCER, 1);
	TIM2->SR = 0;
	TIM2->CCR1 = 300;
	TIM2->CR1 |= (1<<0);			// 타이머 돌아가라이이잇
	/*
	TIM2->CR1 = (1 << 4 | 0 << 3);
	TIM2->PSC = (int)(TIMXCLK / TIM2_FREQ) - 1;
	TIM2->ARR = 1000 - 1; // 해상도 천짜리임
	TIM2->EGR = (1 << 0);
	TIM2->CCMR1 = ((1 << 6) | (1 << 5) | (1 << 13) | (1 << 14) | (1 << 3) | (1 << 11)); // 채널 1번 2번 둘다 110으로 세팅
	TIM2->CCER = ((0 << 0) | (0 << 4));													// 채널 1번 2번 둘다 아웃핀 출력 인에이블 잇다가 해주면됨
	TIM2->SR = 0;
	TIM2->CCR1 = 300;
	TIM2->CR1 |= (1<<0);			// 타이머 돌아가라이이잇
	*/
	
}
/*
과거의 유산
void TIM2_init_self(void){
	// 임마를 이제 pwm 제어하는 놈으로 바꿔야된다.
	// 개념적으로 생각해보자....방향을 전환할때만 pwm 제어를 해야되고 멈출때는 gpio제어로 돌아가야됨
	Macro_Set_Bit(RCC->APB1ENR, 0);
	TIM2->CR1 = ((1<<4) | (1<<3));
	TIM2->PSC = (int)(TIMXCLK/TIM2_FREQ) - 1;
	TIM2->ARR = (1000 * TIM2_1ms_Pls) - 1;
	TIM2->EGR = (1<<0);
	TIM2->SR = 0;
}
void  TIM2_start_self(void){	//
	TIM2->CNT = TIM2->ARR;
	TIM2->SR = 0;               // 기존 쓰레기 지옥으로갓
	handle_lock = 1;
	TIM2->CR1 |= (1<<0);
}

void  TIM2_stop_self(void){
	// 개 멍청하게 코드짠부분 뭔생각으로 이리짜니가 당연히 안멈추지 ㅋㅋ
	//  TIM2->CR1 |= (0<<0);
	TIM2_init_self();
}

*/

// 타이머 5 생성 1cycle에 1ms
// 과거의 유산이다 이제 TMIER5는 안쓴다
#define TIM5_TICK (100)					// usec
#define TIM5_FREQ (1000000 / TIM5_TICK) // 10,000Hz
#define TIM5_1ms_PLS (1000 / TIM5_TICK) // 10회

void TIM5_init_self(void)
{
	Macro_Set_Bit(RCC->APB1ENR, 3);
	TIM5->CR1 = (1 << 4);
	TIM5->PSC = (TIMXCLK / TIM5_FREQ) - 1;
	TIM5->ARR = TIM5_1ms_PLS - 1;
	TIM5->EGR = (1 << 0);
	TIM5->SR = 0;
}
void TIM5_start_self(void)
{
	TIM5->CNT = TIM5->ARR; // 기존에 이;ㅆ느 쓰레기 없애기
	TIM5->SR = 0;		   // 기존 쓰레기 지옥으로갓
	TIM5->CR1 |= (1 << 0);
}

void TIM5_stop_self(void)
{
	// TIM5->CR1 |= (0<<0);
	// Macro_Set_Bit(TIM5->CR1,0);
	// TIM5->SR = 0;
	TIM5_init_self();
}

void uart_Motor_CW(void)
{
	uart_Motor_Stop();
	// 한쪽만 끄고 한쪽만 키기
	Macro_Clear_Bit(GPIOA->ODR, 0);
	Macro_Write_Block(GPIOA->MODER, 0x3, 0x1, 0);
	// PA1 Alternate Function: TIM2_CH2
	Macro_Write_Block(GPIOA->MODER, 0x3, 0x2, 2);
	TIM2->CCR1 = 0;
	TIM2->CCR2 = pwm_motor_value;
	TIM2->CNT = 0;
	TIM2->EGR = (1 << 0);
	TIM2->SR = 0;
	// 딸깍
	Macro_Clear_Bit(TIM2->CCER, 0);
	Macro_Set_Bit(TIM2->CCER, 4);
	// x타이머 2번 켜
	Macro_Set_Bit(TIM2->CR1, 0);
}
void uart_Motor_CCW(void)
{
	uart_Motor_Stop();
	// 한쪽만 끄고 한쪽만 키기
	Macro_Write_Block(GPIOA->MODER, 0x3, 0x2, 0);
	// 딸깍
	Macro_Clear_Bit(GPIOA->ODR, 1);
	Macro_Write_Block(GPIOA->MODER, 0x3, 0x1, 2);

	TIM2->CCR1 = pwm_motor_value;
	TIM2->CCR2 = 0;

	TIM2->CNT = 0;
	TIM2->EGR = (1 << 0);
	TIM2->SR = 0;
	// 까까딸ㄲ
	Macro_Set_Bit(TIM2->CCER, 0);
	Macro_Clear_Bit(TIM2->CCER, 4);

	// 키는거 ㄲ먹으면ㅇ노딤
	Macro_Set_Bit(TIM2->CR1, 0);
}
void uart_Motor_Stop(void)
{
	// TIM2 PWM 정지
	Macro_Clear_Bit(TIM2->CR1, 0);

	// TIM2 CH1, CH2 출력 비활성화
	Macro_Clear_Bit(TIM2->CCER, 0);
	Macro_Clear_Bit(TIM2->CCER, 4);

	TIM2->CCR1 = 0;
	TIM2->CCR2 = 0;

	// GPIO 출력값을 먼저 0으로 준비
	Macro_Clear_Bit(GPIOA->ODR, 0);
	Macro_Clear_Bit(GPIOA->ODR, 1);

	// PA0, PA1 GPIO 출력
	Macro_Write_Block(GPIOA->MODER, 0x3, 0x1, 0);
	Macro_Write_Block(GPIOA->MODER, 0x3, 0x1, 2);
}

// uart로 PWM 활용하여 모터 제어하기
void uart_motor_handle(void)
{
	if (Uart_Data_In == 0)
	{	// 야 유아트 안들어 왔으니까 볼필요 없제?
		return;
	}
	// 유아트 1일로 들어와서 봣으니까 0으로 만들고 함수 돌려
	Uart_Data_In = 0;
	if (Uart_Data >= '0' && Uart_Data <= '9')
	{
		int previous_uart_pwm_mode = uart_pwm_mode;
		pwm_motor_value = 500 + ((Uart_Data - '0') * 50);
		uart_pwm_mode = 1;

		if (handle_lock == 0)
		{
			if (motor_state == stop)
			{
				// 정지 상태:
				// 입력된 PWM으로 정방향 시작
				motor_state = CW;
				uart_Motor_CW();
			}
			else if (motor_state == CW)
			{
				if (previous_uart_pwm_mode == 1)
				{
					// 이미 UART PWM 정방향 회전 중:
					// PWM 값만 변경
					TIM2->CCR2 = pwm_motor_value;
				}
				else
				{
					uart_Motor_CW();
				}
			}
			else if (motor_state == CCW)
			{
				if (previous_uart_pwm_mode == 1)
				{
					TIM2->CCR1 = pwm_motor_value;
				}
				else
				{
					uart_Motor_CCW();
				}
			}
		}
	}
	else if (Uart_Data == 'S')
	{
		// ㅇㅇㄱㄱ
		if (handle_lock == 1)
		{
			TIM4_Repeat_Interrupt_Enable(0, 0);
			TIM4_Expired = 0;
			handle_lock = 0;
		}
		uart_pwm_mode = 1;
		motor_state = stop;
		uart_Motor_Stop();
	}
	else if (Uart_Data == 'F')
	{
		uart_pwm_mode = 1;

		if (handle_lock == 1)
		{
			// 대지궁
			motor_state = CW;
		}
		else if (motor_state == CCW)
		{
			// 정지
			motor_state = CW;
			Motor_Stop();
		}
		else
		{
			motor_state = CW;
			uart_Motor_CW();
		}
	}
	else if (Uart_Data == 'R')
	{
		uart_pwm_mode = 1;

		if (handle_lock == 1)
		{
			motor_state = CCW;
		}
		else if (motor_state == CW)
		{
			// 정지
			motor_state = CCW;
			Motor_Stop();
		}
		else
		{
			motor_state = CCW;
			uart_Motor_CCW();
		}
	}
}
void Motor_Handle(void)
{
	//  모터 딱 멈췄다잉
	if (handle_lock == 1)
	{
		//
		// 1초 타이머 인터럽트 들어왔냐?
		if (TIM4_Expired == 0)
		{ // 안들어왔으면 함수 나가라
			return;
		}

		TIM4_Expired = 0;
		// 인터럽트 꺼버려잇.
		TIM4_Repeat_Interrupt_Enable(0, 0);
		handle_lock = 0;

		// 모터에 부하가 안걸립니다 바꿔도 됩니다.
		if (motor_state == CW)
		{
			Motor_CW();
		}
		else if (motor_state == CCW)
		{
			Motor_CCW();
		}
		return;
	}

	switch (motor_state)
	{
		// 각각 상태만 천이시켜줌
	case stop:
		if (button_event == BUTTON_SHORT)
		{
			Motor_CW();
			motor_state = CW;
		}
		break;

	case CW:
		if (button_event == BUTTON_SHORT)
		{
			motor_state = CCW;
			// Motor_CCW();
			Motor_Stop(); // 한번 멈춰주기
		}
		else if (button_event == BUTTON_LONG)
		{
			Motor_Stop();
			motor_state = stop;
		}
		break;

	case CCW:
		if (button_event == BUTTON_SHORT)
		{
			motor_state = CW;
			// Motor_CW();
			Motor_Stop(); // 한번 멈춰주기
		}
		else if (button_event == BUTTON_LONG)
		{
			Motor_Stop();
			motor_state = stop;
		}
		break;
	}
	button_event = BUTTON_NONE;
}

void Motor_CW(void)
{
	// ㅇㅇ
	if (uart_pwm_mode == 1)
	{
		uart_Motor_CW();
		return;
	}

	uart_Motor_Stop();

	Macro_Write_Block(GPIOA->MODER, 0x3, 0x1, 0);
	Macro_Write_Block(GPIOA->MODER, 0x3, 0x1, 2);

	Macro_Write_Block(GPIOA->ODR, 0x1, 0x0, 0);
	Macro_Write_Block(GPIOA->ODR, 0x1, 0x1, 1);
}

void Motor_CCW(void)
{
	if (uart_pwm_mode == 1)
	{
		uart_Motor_CCW();
		return;
	}

	uart_Motor_Stop();

	Macro_Write_Block(GPIOA->MODER, 0x3, 0x1, 0);
	Macro_Write_Block(GPIOA->MODER, 0x3, 0x1, 2);

	Macro_Write_Block(GPIOA->ODR, 0x1, 0x1, 0);
	Macro_Write_Block(GPIOA->ODR, 0x1, 0x0, 1);
}

void Motor_Stop(void)
{
	uart_Motor_Stop();
	Motor_Wait();
}

void Motor_Wait(void)
{
	// printf("motoer___________start_______\n");
	// TIM2_start_self();
	TIM4_Expired = 0;
	handle_lock = 1;
	TIM4_Repeat_Interrupt_Enable(1, 1000);
}

void Button_Event_Handle(void)
{
	// 1ms가 안지낫는데 먼저 들어오면 안되겟죠?
	if (!Macro_Check_Bit_Set(TIM5->SR, 0))	// 1ms 마다 플래그가 서는데 그걸 본다.
	{
		return;
	}
	// 들어왓으니 플래그 초기화해줘
	TIM5->SR = 0;
	// 현재 버튼 상태를 읽는다.
	button_raw = Macro_Extract_Area(~GPIOA->IDR, 0x1, 4);
	// 이전 값과 같은지 아닌지
	if (button_raw == button_raw_prev)
	{
		if (button_same_count < BUTTON_STABLE_COUNT)
		{
			button_same_count++;
		}
	}
	else
	{
		button_raw_prev = button_raw;
		button_same_count = 1;
	}

	// 새 버튼값이 100번 연속으로 들어왔고 그 값이 기존에 확정된 상태와 다를 때만 버튼 상태를 변경한다.

	if ((button_same_count >= BUTTON_STABLE_COUNT) && (button_stable != button_raw_prev))
	{

		button_stable = button_raw_prev;

		// 버튼 눌린 상태
		if (button_stable == 1)
		{
			Button_lock = 1;
			long_press_detected = 0;
			Sys_Time = 0;
		}
		else
		{ // 버튼 안 눌린 상태
			if (Button_lock == 1)
			{
				Button_lock = 0;

				if (long_press_detected == 0)
				{
					uart_pwm_mode = 0;
					button_event = BUTTON_SHORT;
				}

				Sys_Time = 0;
				long_press_detected = 0;
			}
		}
	}

	// 버튼 눌렷고, 상태 확정했고, 3초 이내로 누르고
	if (Button_lock == 1 && button_stable == 1 && long_press_detected == 0)
	{
		Sys_Time++;

		if (Sys_Time >= 3000)
		{
			long_press_detected = 1;
			uart_pwm_mode = 0;
			button_event = BUTTON_LONG;
		}
	}
}

// uart timer(pwm) 다른 c 파일에 구현했음
// 일단 uart는 모듈 사용 가능함.
// uart로 받아온 값을 저장해야됨
// uart하고 버튼으로 둘다 제어가 가능하게 맹글어본다.
// tim5 	1ms 재는용도
// tim2		pwm
// tim4		1초 정지 체크 타이머




#if 1
void Main(void)
{
	Sys_Init(115200);
	motor_pwm_timer_init_self();
	for (;;)
	{
		if(Macro_Extract_Area(TIM2->SR,0x1,0) == 1){
			Macro_Set_Bit(TIM2->SR,0);
		}
	}
}

#else


#if 1
void Main(void)
{
	Sys_Init(115200);
	button_motor_init_myself();
	// TIM2_init_self();
	TIM5_init_self();
	TIM5_start_self();
	Uart2_RX_Interrupt_Enable(1);
	motor_pwm_timer_init_self();
	printf("경기~~~~~~~시작 하겠습니다!\n");
	for (;;)
	{
		// printf("in_%c handle_lock : %d motor_state : %d\n",Uart_Data, handle_lock, motor_state);
		uart_motor_handle();
		if (handle_lock == 0)
		{
			Button_Event_Handle();
		}
		Motor_Handle();
	}
}
#else
void Main(void)
{
	Sys_Init(115200);
	button_motor_init_myself();
	// TIM2_init_self();
	TIM5_init_self();
	TIM5_start_self();
	Uart2_RX_Interrupt_Enable(1);
	motor_pwm_timer_init_self();
	printf("유아트 켜졋다잉\n");
	TIM2->CCR1 = 0;
	TIM2->CCR2 = 900; // 500이 50퍼임 잘기억하셈 일단 켜졋다하면 50퍼출력이댜
	uart_Motor_CW();
}
#endif
// 모터 핸들에서 방향전환할때 멈추는데 멈출때만 핸들락이 1이 된다.

#endif