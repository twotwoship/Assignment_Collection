#include "device_driver.h"
#include <stdio.h>

void _Invalid_ISR(void)
{
	unsigned int r = Macro_Extract_Area(SCB->ICSR, 0x1ff, 0);
	printf("\nInvalid_Exception: %d!\n", r);
	printf("Invalid_ISR: %d!\n", r - 16);
	for(;;);
}

extern volatile int _GRB[];

void TIM3_IRQHandler(void){
    static int check = 0;
    static int stop_pending = 0;

    Macro_Clear_Bit(TIM3->SR, 0);

    if(stop_pending){   // 나는 이 게임을 해봤어요!!!!
        BIG__EYE__TIM3_interrupt_en(0);
        check = 1;
        stop_pending = 0;
        return;
    }
    // 다돌면?
    if(check < 96){
        TIM3->CCR1 = _GRB[check];
        check++;
    }else{
        TIM3->CCR1 = TIM3->ARR;
        stop_pending = 1;
    }
}

extern volatile int Key_Pressed;

void EXTI15_10_IRQHandler(void)
{
	Key_Pressed = 1;
	
	EXTI->PR = 0x1 << 13;
	NVIC_ClearPendingIRQ(40);
}
